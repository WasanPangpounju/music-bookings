from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import SessionLocal, engine, Base
from models import Room, Booking
from datetime import date, time, datetime

Base.metadata.create_all(bind=engine)

app = FastAPI()
templates = Jinja2Templates(directory="templates")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
def home(request: Request, db: Session = Depends(get_db)):
    rooms = db.query(Room).all()
    return templates.TemplateResponse("index.html", {"request": request, "rooms": rooms})

@app.get("/room/{room_id}")
def room_page(room_id: int, request: Request, db: Session = Depends(get_db)):
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404)
    bookings = db.query(Booking).filter(Booking.room_id == room_id).all()
    return templates.TemplateResponse("room.html", {"request": request, "room": room, "bookings": bookings})

@app.post("/book/{room_id}")
def book_room(
    room_id: int,
    request: Request,
    date: date = Form(...),
    start_time: time = Form(...),
    end_time: time = Form(...),
    person_name: str = Form(...),
    person_email: str = Form(...),
    db: Session = Depends(get_db),
):
    # Check overlapping bookings
    overlaps = db.query(Booking).filter(
        Booking.room_id == room_id,
        Booking.date == date,
        Booking.start_time < end_time,
        Booking.end_time > start_time
    ).all()

    if overlaps:
        return templates.TemplateResponse(
            "room.html",
            {
                "request": request,
                "room": db.query(Room).filter(Room.id == room_id).first(),
                "bookings": db.query(Booking).filter(Booking.room_id == room_id).all(),
                "error": "เวลานี้ถูกจองแล้ว กรุณาเลือกเวลาอื่น",
            },
        )

    new_booking = Booking(
        room_id=room_id,
        date=date,
        start_time=start_time,
        end_time=end_time,
        person_name=person_name,
        person_email=person_email,
    )
    db.add(new_booking)
    db.commit()
    return RedirectResponse(f"/room/{room_id}", status_code=303)
